%Computer Exercise 2

w_base = 314.59;
K = sqrt(3/2);
V_rated = 1;
w_rated = 1;

% RR = 
% RS = 
% LM = 
% Ls = %L_sigma
% J = 
% p = 
% b = 


